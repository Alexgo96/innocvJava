package restpackage;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SuppressWarnings("deprecation")
public class Inventory {
	
	private static Inventory instance;
	private static List<User> inventory = new ArrayList<User>();
	
	static {
		User u1 = new User(0, "John", new Date(100, 3, 20));
		User u2 = new User(1, "Jane", new Date(93, 6, 3));
		
		inventory.add(u1);
		inventory.add(u2);
	}
	
	private Inventory() {}
	
	public static Inventory getInstance() {
		if(instance == null) {
			instance = new Inventory();
		}
		
		return instance;
	}
	
	public List<User> listAll(){ return inventory; }
	
	public User read(int id) { return inventory.get(id); }
	
	public void create(User u) {
		inventory.add(u);
	}
	
	public boolean update(User u, int id) {
		
		if(id >= 0) {
			inventory.set(id, u);
			return true;
		}
		else
			return false;
	}
	
	public boolean delete(int id) {
		
		if(id >= 0) {
			inventory.remove(id);
			return true;
		}
		else
			return false;
	}

}
